package com.rradio.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.media.AudioAttributes;
import android.media.MediaPlayer;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(17,19,26), CARD = Color.rgb(31,34,44), GOLD = Color.rgb(222,177,86), WHITE = Color.WHITE, MUTED = Color.rgb(183,187,199);
    private LinearLayout root, stationList;
    private TextView status, nowPlaying;
    private EditText search;
    private MediaPlayer player;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayList<Station> stations = new ArrayList<>();

    static class Station {
        String name, url, country;
        Station(String n, String u, String c) { name=n; url=u; country=c; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadStations("Hindi");
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w,h); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        root = vertical(); root.setPadding(dp(20), dp(26), dp(20), dp(24)); scroll.addView(root);
        setContentView(scroll);

        TextView logo = text("📻  R RADIO", 28, GOLD, true);
        root.addView(logo);
        TextView subtitle = text("পুরোনো হিন্দি গানের রেডিও", 15, MUTED, false);
        LinearLayout.LayoutParams sublp = lp(-2,-2); sublp.topMargin=dp(5); root.addView(subtitle,sublp);

        LinearLayout playerCard = vertical(); playerCard.setPadding(dp(18),dp(18),dp(18),dp(18)); playerCard.setBackground(shape(CARD, dp(18)));
        LinearLayout.LayoutParams clp = lp(-1,-2); clp.topMargin=dp(22); root.addView(playerCard,clp);
        TextView disc = text("♫", 46, GOLD, true); disc.setGravity(Gravity.CENTER); playerCard.addView(disc, lp(-1,-2));
        nowPlaying = text("এখন কোনো স্টেশন চলছে না", 17, WHITE, true); nowPlaying.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nlp=lp(-1,-2); nlp.topMargin=dp(8); playerCard.addView(nowPlaying,nlp);
        status = text("স্টেশন লোড হচ্ছে…", 13, MUTED, false); status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stlp=lp(-1,-2); stlp.topMargin=dp(6); playerCard.addView(status,stlp);
        Button stop = new Button(this); stop.setText("বন্ধ করুন"); stop.setOnClickListener(v -> stopPlayback());
        LinearLayout.LayoutParams stoplp=lp(-1,-2); stoplp.topMargin=dp(12); playerCard.addView(stop,stoplp);

        TextView heading=text("রেডিও স্টেশন",21,WHITE,true);
        LinearLayout.LayoutParams hlp=lp(-1,-2); hlp.topMargin=dp(24); root.addView(heading,hlp);

        LinearLayout searchRow = new LinearLayout(this); searchRow.setOrientation(LinearLayout.HORIZONTAL);
        search = new EditText(this); search.setSingleLine(true); search.setTextColor(WHITE); search.setHintTextColor(MUTED);
        search.setHint("Hindi / Bollywood / Retro"); search.setPadding(dp(12),0,dp(12),0); search.setBackground(shape(CARD,dp(12)));
        searchRow.addView(search,new LinearLayout.LayoutParams(0,dp(50),1));
        Button go = new Button(this); go.setText("খুঁজুন"); go.setOnClickListener(v -> loadStations(search.getText().toString().trim()));
        LinearLayout.LayoutParams glp=lp(-2,dp(50)); glp.leftMargin=dp(8); searchRow.addView(go,glp);
        LinearLayout.LayoutParams rlp=lp(-1,-2); rlp.topMargin=dp(12); root.addView(searchRow,rlp);

        stationList=vertical(); LinearLayout.LayoutParams listlp=lp(-1,-2); listlp.topMargin=dp(12); root.addView(stationList,listlp);
        TextView foot=text("স্টেশনগুলো অনলাইন ডিরেক্টরি থেকে আসে। কোনো স্ট্রিম বন্ধ থাকলে অন্য স্টেশন চেষ্টা করো।",12,MUTED,false);
        LinearLayout.LayoutParams flp=lp(-1,-2); flp.topMargin=dp(18); root.addView(foot,flp);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void loadStations(String term) {
        if (term == null || term.trim().isEmpty()) term = "Hindi";
        final String query=term.trim();
        status.setText("স্টেশন খোঁজা হচ্ছে…");
        stationList.removeAllViews();
        executor.execute(() -> {
            ArrayList<Station> found = new ArrayList<>();
            HttpURLConnection conn=null;
            try {
                String encoded=URLEncoder.encode(query,"UTF-8");
                URL url=new URL("https://de1.api.radio-browser.info/json/stations/search?name="+encoded+"&limit=30&hidebroken=true&order=clickcount&reverse=true");
                conn=(HttpURLConnection)url.openConnection();
                conn.setConnectTimeout(10000); conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent","RRadio/1.0 Android");
                int code=conn.getResponseCode();
                if(code==200) {
                    BufferedReader br=new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-8"));
                    StringBuilder sb=new StringBuilder(); String line;
                    while((line=br.readLine())!=null) sb.append(line); br.close();
                    JSONArray arr=new JSONArray(sb.toString());
                    for(int i=0;i<arr.length();i++) {
                        JSONObject o=arr.getJSONObject(i);
                        String name=o.optString("name","").trim();
                        String stream=o.optString("url_resolved",o.optString("url","")).trim();
                        String country=o.optString("country","").trim();
                        if(!name.isEmpty() && stream.startsWith("http")) found.add(new Station(name,stream,country));
                    }
                }
            } catch(Exception ignored) {}
            finally { if(conn!=null) conn.disconnect(); }
            final ArrayList<Station> result=found;
            main.post(() -> {
                stations.clear(); stations.addAll(result); stationList.removeAllViews();
                if(result.isEmpty()) {
                    status.setText("স্টেশন পাওয়া যায়নি। ইন্টারনেট চালু করে আবার চেষ্টা করো।");
                    TextView hint=text("সার্চে Hindi, Bollywood, Retro বা Vividh Bharati লিখে দেখো।",14,MUTED,false);
                    stationList.addView(hint);
                    return;
                }
                status.setText(result.size()+"টি স্টেশন পাওয়া গেছে");
                for(Station s:result) addStation(s);
            });
        });
    }

    private void addStation(Station s) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14),dp(12),dp(10),dp(12)); row.setBackground(shape(CARD,dp(14)));
        LinearLayout.LayoutParams rlp=lp(-1,-2); rlp.topMargin=dp(8); stationList.addView(row,rlp);
        LinearLayout info=vertical();
        TextView name=text(s.name,15,WHITE,true); name.setMaxLines(2); info.addView(name);
        TextView country=text(s.country.isEmpty()?"অনলাইন রেডিও":s.country,12,MUTED,false);
        LinearLayout.LayoutParams c=lp(-1,-2); c.topMargin=dp(4); info.addView(country,c);
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Button play=new Button(this); play.setText("▶ চালাও"); play.setOnClickListener(v -> playStation(s));
        row.addView(play,lp(-2,dp(48)));
    }

    private void playStation(Station s) {
        stopPlayerOnly();
        nowPlaying.setText(s.name);
        status.setText("সংযোগ হচ্ছে…");
        try {
            player=new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(s.url);
            player.setOnPreparedListener(mp -> { mp.start(); status.setText("চলছে  •  "+s.country); });
            player.setOnErrorListener((mp, what, extra) -> { status.setText("এই স্টেশনটি চলছে না—অন্যটি চেষ্টা করো।"); stopPlayerOnly(); return true; });
            player.prepareAsync();
        } catch(Exception e) { status.setText("চালু করা যায়নি। অন্য স্টেশন চেষ্টা করো।"); stopPlayerOnly(); }
    }
    private void stopPlayerOnly() {
        if(player!=null) { try { if(player.isPlaying()) player.stop(); } catch(Exception ignored) {} try { player.release(); } catch(Exception ignored) {} player=null; }
    }
    private void stopPlayback() {
        stopPlayerOnly(); nowPlaying.setText("এখন কোনো স্টেশন চলছে না"); status.setText("রেডিও বন্ধ করা হয়েছে");
    }
    @Override protected void onDestroy() { stopPlayerOnly(); executor.shutdownNow(); super.onDestroy(); }
}
