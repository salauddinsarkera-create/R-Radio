# R Radio — Android অ্যাপ

এটি Android Studio-তে খোলার মতো একটি সাধারণ Java Android প্রজেক্ট। অ্যাপটি Radio Browser-এর পাবলিক ডিরেক্টরি থেকে Hindi/Bollywood/Retro স্টেশন খোঁজে এবং স্ট্রিম চালানোর চেষ্টা করে।

## কী আছে
- বাংলা UI
- স্টেশন সার্চ
- লাইভ স্টেশন প্লে/স্টপ
- স্ট্রিম কাজ না করলে বার্তা
- ইন্টারনেট অনুমতি

## APK বানানোর ধাপ
1. কম্পিউটারে Android Studio ইনস্টল করো: https://developer.android.com/studio
2. ZIP ফাইলটি Extract করো।
3. Android Studio → **Open** → Extract করা `R_Radio_Android_Project` ফোল্ডারটি বেছে নাও।
4. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করো। প্রয়োজন হলে Android SDK Platform 35 ইনস্টল করো।
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** চাপো।
6. APK সাধারণত এখানে পাওয়া যাবে: `app/build/outputs/apk/debug/app-debug.apk`
7. APK ফোনে পাঠিয়ে ইনস্টল করো। Android-এ “Install unknown apps” অনুমতি চাইতে পারে—শুধু নিজের তৈরি/বিশ্বস্ত APK-তেই অনুমতি দিও।

## ফোনেই তৈরি করতে চাইলে
Android Studio কম্পিউটারে ব্যবহার করাই সবচেয়ে সহজ। ফোনে শুধু ZIP Extract করলেই APK তৈরি হবে না; Android build environment প্রয়োজন।

## গুরুত্বপূর্ণ
- এই ZIP-এ APK নয়, সোর্স কোড ও প্রজেক্ট ফাইল আছে।
- স্টেশনগুলো তৃতীয় পক্ষের Radio Browser ডিরেক্টরি থেকে আসে। সব স্ট্রিম সবসময় কাজ করবে—এমন নিশ্চয়তা নেই।
- এটি প্রথম সংস্করণ; ব্যাকগ্রাউন্ডে দীর্ঘক্ষণ বাজানো, নোটিফিকেশন/মিডিয়া কন্ট্রোল এবং ফেভারিট তালিকা এখনো যোগ করা হয়নি।
